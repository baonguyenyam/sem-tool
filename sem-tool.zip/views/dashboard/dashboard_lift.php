<ul>
	<li>
		<a href="keywork-generator">
		<i class="bi bi-type-h1 fa-3x fa-fw me-1"></i>
		<span>Keywords Generator</span>
		</a>
	</li>
	<li>
		<a href="post-generator">
		<i class="bi bi-stickies fa-3x fa-fw me-1"></i>
		<span>WordPress Post Generator</span>
		</a>
	</li>
	<li>
		<a href="content-generator">
		<i class="bi bi-bullseye fa-3x fa-fw me-1"></i>
		<span>Content SEO Generator</span>
		</a>
	</li>

	<li>
		<a href="qr-generator">
		<i class="bi bi-upc-scan fa-3x fa-fw me-1"></i>
		<span>QR Code Generator</span>
		</a>
	</li>
	<!-- <li>
		<a href="image-generator">
		<i class="bi bi-camera fa-3x fa-fw me-1"></i>
		<span>Image Generator</span>
		</a>
	</li> -->
	<li>
		<a href="favicon-generator">
		<i class="bi bi-command fa-3x fa-fw me-1"></i>
		<span>Favicon Generator</span>
		</a>
	</li>
	<li>
		<a href="robots-generator">
		<i class="bi bi-bug fa-3x fa-fw me-1"></i>
		<span>Robots.txt Generator</span>
		</a>
	</li>

	<li>
		<a href="plugin-generator">
		<i class="bi bi-cloud-download fa-3x fa-fw me-1"></i>
		<span>Plugin Generator</span>
		</a>
	</li>

	<li>
		<a href="wp-plugins">
		<i class="bi bi-archive fa-3x fa-fw me-1"></i>
		<span>WordPress Plugins</span>
		</a>
	</li>
	<li>
		<a href="banner-creator/index.html" target="_blank">
		<i class="bi bi-camera fa-3x fa-fw me-1"></i>
		<span>Banner Creator</span>
		</a>
	</li>
	<li>
		<a href="chrome-extensions">
		<i class="bi bi-box-seam fa-3x fa-fw me-1"></i>
		<span>Chrome Extensions</span>
		</a>
	</li>
	<li>
		<a href="html-validator">
		<i class="bi bi-check2-all fa-3x fa-fw me-1"></i>
		<span>HTML Code Validator</span>
		</a>
	</li>
	<li>
		<a href="pagespeed">
		<i class="bi bi-graph-up fa-3x fa-fw me-1"></i>
		<span>PageSpeed Insights</span>
		</a>
	</li>
	<li>
		<a href="ping">
		<i class="bi bi-arrow-left-right fa-3x fa-fw me-1"></i>
		<span>Ping Your Website</span>
		</a>
	</li>
	<li>
		<a href="domain">
		<i class="bi bi-globe fa-3x fa-fw me-1"></i>
		<span>WHOIS Domain Lookup</span>
		</a>
	</li>
	<li>
		<a href="crawler">
		<i class="bi bi-lightning fa-3x fa-fw me-1"></i>
		<span>Crawler List</span>
		</a>
	</li>
	<li>
		<a href="app">
		<i class="bi bi-laptop fa-3x fa-fw me-1"></i>
		<span>Desktop App</span>
		</a>
	</li>
	<li>
		<a href="https://docs.myseo.website/" target="_blank">
		<i class="bi bi-journal-bookmark fa-3x fa-fw me-1"></i>
		<span>Guideline</span>
		</a>
	</li>
	<li>
		<a href="https://myseo.website/wp" target="_blank">
		<i class="bi bi-braces fa-3x fa-fw me-1"></i>
		<span>Testing Site</span>
		</a>
	</li>
</ul>