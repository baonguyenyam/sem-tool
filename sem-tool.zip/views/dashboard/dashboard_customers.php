<ul>
	<li>
		<a href="favicon-generator">
		<i class="bi bi-command fa-3x fa-fw me-1"></i>
		<span>Favicon generator</span>
		</a>
	</li>
	<li>
		<a href="html-validator">
		<i class="bi bi-check2-all fa-3x fa-fw me-1"></i>
		<span>HTML Code validator</span>
		</a>
	</li>
	<li>
		<a href="banner-creator" target="_blank">
		<i class="bi bi-camera fa-3x fa-fw me-1"></i>
		<span>Banner Creator</span>
		</a>
	</li>
	<li>
		<a href="crawler">
		<i class="bi bi-lightning fa-3x fa-fw me-1"></i>
		<span>Crawler list</span>
		</a>
	</li>
</ul>