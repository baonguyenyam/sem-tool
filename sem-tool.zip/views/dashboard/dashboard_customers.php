<ul>
	<li>
		<a href="favicon-generator">
		<i class="bi bi-command fa-3x fa-fw me-1"></i>
		<span>Favicon Generator</span>
		</a>
	</li>
	<li>
		<a href="banner-creator/index.html" target="_blank">
		<i class="bi bi-camera fa-3x fa-fw me-1"></i>
		<span>Banner Creator</span>
		</a>
	</li>
	<li>
		<a href="domain">
		<i class="bi bi-globe fa-3x fa-fw me-1"></i>
		<span>WHOIS Domain Lookup</span>
		</a>
	</li>
	<li>
		<a href="crawler">
		<i class="bi bi-lightning fa-3x fa-fw me-1"></i>
		<span>Crawler List</span>
		</a>
	</li>
</ul>