<?php require './db/Auth.php'; $auth = new Auth(); ?>
