<script src="/assets/js/function.min.js"></script>
<script src="/assets/js/lift.min.js"></script>
<script src="/assets/js/bootstrap.bundle.min.js"></script>