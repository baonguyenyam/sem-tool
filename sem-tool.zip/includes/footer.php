<script src="/assets/js/vendor/bootstrap.bundle.min.js"></script>
<script src="/assets/js/dist/function.prod.js"></script>
<script src="/assets/js/dist/lift.prod.js"></script>