<?php
define("LIFT_VERSION", "3.8.0");
define("LIFT_TITLE", "LIFT Creations ✅");
