<?php
define("LIFT_VERSION", "3.0.6");
define("LIFT_TITLE", "LIFT Creations ✅");
