<?php
define("LIFT_DEV", false);
define("LIFT_VERSION", "4.5.0");
define("LIFT_TITLE", "LIFT Creations ✅");
