<?php 

$output .= '<section'. $block_id .' class="lift-elements lift-' . $this->name . $theme . $css_class .''.($add_box_button ? ' lift-hold-click' : '').'"' . str_replace('``', '', $attribute) . '>';
$output .= '<article class="lift-ctn'.$textAlign.'">';
$icon_position && $icon_position ==='style-1' ? include 'inc/icon.php' : null;
$output .= $title ? $applyFont : null;
$icon_position && $icon_position ==='style-2' ? include 'inc/icon.php' : null;
$output .= $content ? '<div class="lift-content"'.$applyDesc.'>' . do_shortcode($content) . '</div>' : null;
$output .= $add_button ? '<p class="lift-button">' . $this->extractLink($link, $title) . '</p>' : null;
$output .= '</article>';
$output .= '<figure class="img-with-aniamtion-wrap'.$dynamic_el_styles. $css_animation .$textAlign.'" '.$wrap_image_attrs_escaped.'>
<div class="hover-wrap-inner">
<img class="img-with-animation skip-lazy '.esc_attr($img_class).'" '.$image_attrs_escaped.' />
</div>
<figcaption></figcaption>
</figure>';
$output .= $add_box_button ? '' . $this->extractLink($link, $title,false,null,true) . '' : null;
$output .= '</section><!-- .lift-' . $this->name . ' -->';