<?php
$output .= $icon ? $this->applyIcon($icon,$icon_size) : null;