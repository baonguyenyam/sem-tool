<?php

/**
 * the WPBakery Visual Composer plugin by Nguyen Pham
 * https://visualcomposer.com/help/api/
 * https://kb.wpbakery.com/docs/developers-how-tos/add-design-options-tab-with-css-editor-to-your-element/
 * https://www.wpelixir.com/how-to-customize-default-elements-visual-composer/
 *
 */

if (!defined('ABSPATH')) {
	die('Silly human what are you doing here');
}


if (!class_exists('liftVC_Addons_CustomPost')) {

	class liftVC_Addons_CustomPost extends LIFT_Helpers
	{

		public $name = 'custompost';
		public $pNicename = 'LIFT Custom Posts';

		public function __construct()
		{

			add_action('wp_enqueue_scripts', array($this, 'load_scripts'));
			add_shortcode('lift-' . $this->name . '-shortcode', array($this, 'output'));

			// Map shortcode to Visual Composer
			if (function_exists('vc_lean_map')) {
				vc_lean_map('lift-' . $this->name . '-shortcode', array($this, 'functionLoader'));
			}
		}

		public function load_scripts()
		{
			wp_enqueue_script(
				'lift-' . $this->name,
				plugin_dir_url(__FILE__) . 'js/dist/main.prod.js',
				array('jquery'),
				LIFT_VERSION
			);
			wp_enqueue_style(
				'lift-' . $this->name,
				plugin_dir_url(__FILE__) . 'css/dist/main.min.css',
				array(),
				LIFT_VERSION
			);
		}

		public function functionLoader()
		{
			return array(
				'name'        => esc_html__($this->pNicename, 'js_composer'),
				'description' => esc_html__('Add new ' . $this->pNicename, 'js_composer'),
				'base'        => 'lift_vc_' . $this->name,
				'category' => __('LIFT Addons', 'js_composer'),
				'icon' => 'icon-lift-adminicon icon-lift-' . $this->name,
				'show_settings_on_create' => true,
				'params'      => array(
					array(
						"type" => "loop",
						"class" => "",
						"heading" => __( "Field Label", "js_composer" ),
						"param_name" => "field_name",
						"value" => __( "", "js_composer" ),
						"description" => __( "Select post types to populate posts from. Note: If no post type is selected, WordPress will use default Post value.", "js_composer" ),
						'admin_label' => true,
						'group' => $this->pNicename,
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__( 'Box layout', 'js_composer' ),
						'param_name' => 'type',
						'admin_label' => true,
						'value' => array(
							esc_html__( 'No Style', 'js_composer' ) => 'none',
							esc_html__( 'Style 1', 'js_composer' ) => 'style1',
							esc_html__( 'Style 2', 'js_composer' ) => 'style2',
							esc_html__( 'Style 3', 'js_composer' ) => 'style3',
							esc_html__( 'Style 4', 'js_composer' ) => 'style4',
							esc_html__( 'Style 5', 'js_composer' ) => 'style5',
						),
						'description' => esc_html__( 'Select box layout.', 'js_composer' ),
						'group' => __('Format', 'js_composer')
					),
					array(
						'type' => 'font_container',
						'param_name' => 'font_container',
						'value' => 'tag:h2|text_align:left',
						'settings' => array(
							'fields' => array(
								'tag' => 'h2',
								// default value h2
								'text_align',
								'font_size',
								'line_height',
								'color',
								'tag_description' => esc_html__('Select element tag.', 'js_composer'),
								'text_align_description' => esc_html__('Select text alignment.', 'js_composer'),
								'font_size_description' => esc_html__('Enter font size.', 'js_composer'),
								'line_height_description' => esc_html__('Enter line height.', 'js_composer'),
								'color_description' => esc_html__('Select heading color.', 'js_composer'),
							),
						),
						'group' => __('Format', 'js_composer')
					),
					array(
						'type' => 'checkbox',
						'heading' => esc_html__('Use theme default font family?', 'js_composer'),
						'param_name' => 'use_theme_fonts',
						'value' => array(esc_html__('Yes', 'js_composer') => 'yes'),
						'description' => esc_html__('Use font family from the theme.', 'js_composer'),
						'group' => __('Format', 'js_composer')
					),
					array(
						'type' => 'google_fonts',
						'param_name' => 'google_fonts',
						'value' => 'font_family:Abril%20Fatface%3Aregular|font_style:400%20regular%3A400%3Anormal',
						'settings' => array(
							'fields' => array(
								'font_family_description' => esc_html__('Select font family.', 'js_composer'),
								'font_style_description' => esc_html__('Select font styling.', 'js_composer'),
							),
						),
						'dependency' => array(
							'element' => 'use_theme_fonts',
							'value_not_equal_to' => 'yes',
						),
						'group' => __('Format', 'js_composer')
					),
					array(
						'type' => 'dropdown',
						'heading' => __('Icon library', 'js_composer'),
						'value' => array(
							esc_html__('None', 'js_composer') => 'none',
							esc_html__('Font Awesome', 'js_composer') => 'fontawesome',
							esc_html__('Iconsmind', 'js_composer') => 'iconsmind',
							esc_html__('Linea', 'js_composer') => 'linea',
							esc_html__('Steadysets', 'js_composer') => 'steadysets',
							esc_html__('Linecons', 'js_composer') => 'linecons',
						),
						'save_always' => true,
						'param_name' => 'icon_family',
						'description' => __('Select icon library.', 'js_composer'),
						'group' => __('Icons', 'js_composer')
					),
					array(
						"type" => "iconpicker",
						"heading" => esc_html__("Icon", "js_composer"),
						"param_name" => "icon_fontawesome",
						"settings" => array("iconsPerPage" => 240),
						"dependency" => array('element' => "icon_family", 'emptyIcon' => false, 'value' => 'fontawesome'),
						"description" => esc_html__("Select icon from library.", "js_composer"),
						'group' => __('Icons', 'js_composer')
					),
					array(
						"type" => "iconpicker",
						"heading" => esc_html__("Icon", "js_composer"),
						"param_name" => "icon_iconsmind",
						"settings" => array('type' => 'iconsmind', 'emptyIcon' => false, "iconsPerPage" => 240),
						"dependency" => array('element' => "icon_family", 'value' => 'iconsmind'),
						"description" => esc_html__("Select icon from library.", "js_composer"),
						'group' => __('Icons', 'js_composer')
					),
					array(
						"type" => "iconpicker",
						"heading" => esc_html__("Icon", "js_composer"),
						"param_name" => "icon_linea",
						"settings" => array('type' => 'linea', "emptyIcon" => false, "iconsPerPage" => 240),
						"dependency" => array('element' => "icon_family", 'value' => 'linea'),
						"description" => esc_html__("Select icon from library.", "js_composer"),
						'group' => __('Icons', 'js_composer')
					),
					array(
						"type" => "iconpicker",
						"heading" => esc_html__("Icon", "js_composer"),
						"param_name" => "icon_linecons",
						"settings" => array('type' => 'linecons', 'emptyIcon' => false, "iconsPerPage" => 240),
						"dependency" => array('element' => "icon_family", 'value' => 'linecons'),
						"description" => esc_html__("Select icon from library.", "js_composer"),
						'group' => __('Icons', 'js_composer')
					),
					array(
						"type" => "iconpicker",
						"heading" => esc_html__("Icon", "js_composer"),
						"param_name" => "icon_steadysets",
						"settings" => array('type' => 'steadysets', 'emptyIcon' => false, "iconsPerPage" => 240),
						"dependency" => array('element' => "icon_family", 'value' => 'steadysets'),
						"description" => esc_html__("Select icon from library.", "js_composer"),
						'group' => __('Icons', 'js_composer')
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Icon Size", "js_composer"),
						"param_name" => "icon_size",
						"dependency" => array('element' => "icon_family", 'value' => array('fontawesome', 'iconsmind', 'linea', 'steadysets', 'linecons')),
						"description" => esc_html__("Don't include \"px\" in your string. e.g. 40", "js_composer"),
						'group' => __('Icons', 'js_composer')
					),
					array(
						"type" => "dropdown",
						"class" => "",
						'save_always' => true,
						"heading" => esc_html__("Image Loading", "salient-core"),
						"param_name" => "image_loading",
						"value" => array(
							"Default" => "default",
							"Lazy Load" => "lazy-load",
						),
						"description" => esc_html__("Determine whether to load the image on page load or to use a lazy load method for higher performance.", "salient-core"),
						'std' => 'default',
						'group' => __('General', 'js_composer')
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Image size', 'js_composer'),
						'param_name' => 'img_size',
						'value' => 'full',
						'description' => esc_html__('Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height)).', 'js_composer'),
						// 'dependency' => array(
						// 	'element' => 'source',
						// 	'value' => array(
						// 		'media_library',
						// 		'featured_image',
						// 	),
						// ),
						'group' => __('General', 'js_composer')
					),
					vcadd_css_animation(),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Animation Delay", "salient-core"),
						"param_name" => "delay",
						"admin_label" => false,
						"description" => esc_html__("Enter delay (in milliseconds) if needed e.g. 150. This parameter comes in handy when creating the animate in \"one by one\" effect.", "salient-core"),
						'group' => __('General', 'js_composer')
					),
					array(
						'type' => 'el_id',
						'heading' => esc_html__('Element ID', 'js_composer'),
						'param_name' => 'el_id',
						'group' => __('General', 'js_composer')
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Extra class name', 'js_composer'),
						'param_name' => 'el_class',
						'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS.', 'js_composer'),
						'group' => __('General', 'js_composer')
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('HTML Attribute', 'js_composer'),
						'param_name' => 'el_attribute',
						'description' => esc_html__('Enter html attr (Example: "data-bg").', 'js_composer'),
						'group' => __('General', 'js_composer')
					),
					array(
						'type' => 'css_editor',
						'heading' => esc_html__('CSS box', 'js_composer'),
						'param_name' => 'css',
						'group' => esc_html__('Design Options', 'js_composer'),
					),

				),
			);
		}

		public function output($atts, $content = null)
		{

			$image_width  = '100';
			$image_height = '100';
			$image_srcset = null;
			$has_dimension_data = false;
			
			$parsed_animation = str_replace(" ","-",$atts['css_animation']);
			$image_src = wp_get_attachment_image_src($atts['bgimg'], $atts['img_size'])[0];
			$image_meta = wp_get_attachment_metadata($atts['bgimg']);
			$css = isset($atts["css"]) ? $atts["css"] : '';
			$delay = isset($atts['delay']) ? $atts['delay'] : '';
			$title = isset($atts['title']) ? $atts['title'] : '';
			$css_animation = isset($atts['css_animation']) ? ' wpb_animate_when_almost_visible wpb_' . $atts['css_animation'] . ' ' . $atts['css_animation'] : '';
			$attribute = isset($atts['el_attribute']) ? ' ' . $atts['el_attribute'] : '';
			$css_class = apply_filters(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class($css, ' '), $this->settings['base'], $atts);
			$font_container_data = isset($atts['font_container']) ? $atts['font_container'] : '';
			$google_fonts_data = isset($atts['google_fonts']) ? $atts['google_fonts'] : '';
			$image_loading = isset($atts['image_loading']) ? $atts['image_loading'] : '';
			$set_title = $this->applyFont($font_container_data, $title);
			$img_class = '';

			// Attributes applied to img.
			$margin_style_attr = '';
  
			// Attributes applied to img-with-animation-wrap.
			$wrap_image_attrs_escaped  = 'data-max-width="'.esc_attr($max_width).'" ';
			$wrap_image_attrs_escaped .= 'data-max-width-mobile="'.esc_attr($max_width_mobile).'" ';
			$wrap_image_attrs_escaped .= 'data-border-radius="'.esc_attr($border_radius).'" ';
			$wrap_image_attrs_escaped .= 'data-shadow="'.esc_attr($box_shadow).'" ';
			$wrap_image_attrs_escaped .= 'data-animation="'.esc_attr(strtolower($parsed_animation)).'" ';
			$wrap_image_attrs_escaped .= $margin_style_attr;
			// Dynamic style classes.
			if( function_exists('nectar_el_dynamic_classnames') ) {
				$dynamic_el_styles = nectar_el_dynamic_classnames('image_with_animation', $atts);
			} else {
				$dynamic_el_styles = '';
			}
			if (function_exists('wp_get_attachment_image_srcset')) {

				$image_srcset_values = wp_get_attachment_image_srcset($atts['bgimg'], $atts['img_size']);
				if ($image_srcset_values) {

					if( 'lazy-load' === $image_loading ) {
						$image_srcset = 'data-nectar-img-srcset="';
					} else {
						$image_srcset = 'srcset="';
					}
					$image_srcset .= $image_srcset_values;
					$image_srcset .= '" sizes="(min-width: 1450px) 75vw, (min-width: 1000px) 85vw, 100vw"';
				}
			}
			if (isset($image_meta['width']) && !empty($image_meta['width'])) {
				$image_width = $image_meta['width'];
			}
			if (isset($image_meta['height']) && !empty($image_meta['height'])) {
				$image_height = $image_meta['height'];
			}

			$wp_img_alt_tag = get_post_meta($atts['bgimg'], '_wp_attachment_image_alt', true);

			if (!empty($wp_img_alt_tag)) {
				$alt_tag = $wp_img_alt_tag;
			}
			$image_url = (isset($image_src)) ? $image_src : '';

			// Needed for lazy loading.  
			if (!empty($image_meta['width']) && !empty($image_meta['height'])) {
				$has_dimension_data = true;
			}
			$image_attrs_escaped = 'data-delay="' . esc_attr($delay) . '" ';
			$image_attrs_escaped .= 'height="' . esc_attr($image_height) . '" ';
			$image_attrs_escaped .= 'width="' . esc_attr($image_width) . '" ';
			$image_attrs_escaped .= 'data-animation="' . esc_attr(strtolower($parsed_animation)) . '" ';
			if( 'lazy-load' === $image_loading && true === $has_dimension_data ) {
				$img_class .= ' nectar-lazy';
				$image_attrs_escaped .= 'data-nectar-img-src="' . esc_url($image_src) . '" ';
			} else {
				$image_attrs_escaped .= 'src="' . esc_url($image_src) . '" ';
			}
			$image_attrs_escaped .= 'alt="' . esc_attr($alt_tag) . '" ';
			$image_attrs_escaped .= $image_srcset;

			// if ( ( ! isset( $atts['use_theme_fonts'] ) || 'yes' !== $atts['use_theme_fonts'] ) && isset( $google_fonts_data['values']['font_family'] ) ) {
			// 	wp_enqueue_style( 'vc_google_fonts_' . vc_build_safe_css_class( $google_fonts_data['values']['font_family'] ), 'https://fonts.googleapis.com/css?family=' . $google_fonts_data['values']['font_family'] . $subsets, [], WPB_VC_VERSION );
			// }

			// Admin
			$settings = shortcode_atts(array(
				'el_attribute' => '',
				'el_id' => '',
				'el_class' => '',
				'field_name' => '',
			), $atts);
			extract($settings);
			// FrontEnd
			$output = $css ? '<style>' . $css . '</style>' : '';
			$output .= '<section id="' . esc_attr($el_id) . '" class="lift-elements lift-' . $this->name . $css_class . $css_animation . '"' . str_replace('``', '', $attribute) . '>';
			$output .= '<figure class="img-with-aniamtion-wrap '.$dynamic_el_styles.'" '.$wrap_image_attrs_escaped.'>
			      <div class="hover-wrap-inner">
			        <img class="img-with-animation skip-lazy '.esc_attr($img_class).'" '.$image_attrs_escaped.' />
			      </div>
			</figure>';
			$output .= '<article class="lift-ctn">';
			$output .= $title ? $set_title : null;
			$output .= $content ? '<div class="lift-content">' . do_shortcode($content) . '</div>' : null;
			$output .= '</article>';
			$output .= '</section><!-- .lift-' . $this->name . ' -->';


			var_dump($field_name);


			return apply_filters(
				'lift_' . $this->name . '_output',
				$output,
				$content,
				$settings
			);
		}
	}
}
new liftVC_Addons_CustomPost;
