<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class LIFT_Helpers extends WPBakeryShortCode {

	public function applyFont($font_container_data, $title = null, $link = null) {
		$styles = $initStyles = '';
		$tag = 'h2';
		foreach ( explode("|",$font_container_data) as $key => $value ) {
			if ( preg_match( '/tag/', $value ) ) {
				$tag = ''.explode(":",$value)[1];
			}
			if ( preg_match( '/color/', $value ) ) {
				$color = 'color:'.urldecode(explode(":",$value)[1]).';';
			}
			if ( preg_match( '/line_height/', $value ) ) {
				$pattern = '/^(\d*(?:\.\d+)?)\s*(px|\%|in|cm|mm|em|rem|ex|pt|pc|vw|vh|vmin|vmax)?$/';
				preg_match( $pattern, explode(":",$value)[1], $matches );
				$lineheight = isset( $matches[2] ) ? 'line-height:'.$matches[0].';' : 'line-height:'.$matches[0].'px;';			
			}
			if ( preg_match( '/font_size/', $value ) ) {
				$pattern = '/^(\d*(?:\.\d+)?)\s*(px|\%|in|cm|mm|em|rem|ex|pt|pc|vw|vh|vmin|vmax)?$/';
				preg_match( $pattern, explode(":",$value)[1], $matches );
				$fontsize = isset( $matches[2] ) ? 'font-size:'.$matches[0].';' : 'font-size:'.$matches[0].'px;';			
			}
		}
		if($color || $fontsize || $lineheight) {
			$initStyles = ' style="'.$color.''.$fontsize.''.$lineheight.'"';
		}
		$url = $this->extractLink($link,$title,false,$initStyles);
		if($url) {
			$styles = '<'.$tag.' class="lift-title"'.$initStyles.'>' . $url . '</'.$tag.'>';
		} else {
			$styles = '<'.$tag.' class="lift-title"'.$initStyles.'>' .  $title . '</'.$tag.'>';
		}
		return $styles;
	}
	public function applyDesc($desc_color = null, $desc_font_size = null,$desc_line_height = null) {
		$styles = '';
		if($desc_color) {
			$color = 'color:'.$desc_color.';';
		}
		if($desc_font_size) {
			$pattern = '/^(\d*(?:\.\d+)?)\s*(px|\%|in|cm|mm|em|rem|ex|pt|pc|vw|vh|vmin|vmax)?$/';
			preg_match( $pattern, $desc_font_size, $matches );
			$fontsize = isset( $matches[2] ) ? 'font-size:'.$matches[0].';' : 'font-size:'.$matches[0].'px;';	
		}
		if($desc_line_height) {
			$pattern = '/^(\d*(?:\.\d+)?)\s*(px|\%|in|cm|mm|em|rem|ex|pt|pc|vw|vh|vmin|vmax)?$/';
			preg_match( $pattern, $desc_line_height, $matches );
			$lineheight = isset( $matches[2] ) ? 'line-height:'.$matches[0].';' : 'line-height:'.$matches[0].'px;';	
		}
		if($color || $fontsize || $lineheight) {
			$styles = ' style="'.$color.''.$fontsize.''.$lineheight.'"';
		}
		return $styles;
	}
	public function applyIcon($icon = null, $icon_size = null) {
		$styles = $doIcon = $fontsize = '';
		if($icon_size) {
			$pattern = '/^(\d*(?:\.\d+)?)\s*(px|\%|in|cm|mm|em|rem|ex|pt|pc|vw|vh|vmin|vmax)?$/';
			preg_match( $pattern, $icon_size, $matches );
			$fontsize = isset( $matches[2] ) ? ' style="font-size:'.$matches[0].';"' : ' style="font-size:'.$matches[0].'px;"';
		}
		if($icon) {
			$styles = ' class="'.$icon.'"';
			$doIcon = '<i'.$styles.''.$fontsize.'></i>';
		}
		return $doIcon;
	}
	public function textAlign($font_container_data) {
		$align = '';
		foreach ( explode("|",$font_container_data) as $key => $value ) {
			if ( preg_match( '/text_align/', $value ) ) {
				$align = ' text-'.explode(":",$value)[1].'';
			}
		}
		return $align;
	}
	public function extractLink($link, $title, $settile = true, $initStyles = null,$removeTitle = false,$btn = false) {
		$URL = $returnURL = $target = $rel = '';
		foreach ( explode("|",$link) as $key => $value ) {
			if ( preg_match( '/url/', $value ) ) {
				$URL = urldecode(explode(":",$value)[1]);
			}
			if ( preg_match( '/title/', $value ) && $settile) {
				$title = urldecode(explode(":",$value)[1]);
			}
			if ( preg_match( '/target/', $value )) {
				$target = ' target="'. explode(":",$value)[1].'"';
			}
			if ( preg_match( '/rel/', $value )) {
				$rel = ' rel="'. explode(":",$value)[1].'"';
			}
		}
		$btn ? $btn = 'btn btn-primary ' : '';
		if($removeTitle) {
			$returnURL = '<a class="'.$btn.'hold-click" href="'.$URL.'"'.$target.''.$rel.''.$initStyles.'></a>';
		} else {
			$returnURL = '<a class="'.$btn.'" href="'.$URL.'"'.$target.''.$rel.''.$initStyles.'>'.$title.'</a>';
		}
		return $returnURL;
	}

}
