<?php 
// Admin MENU
function admin_lift_menu($meta = TRUE){
    global $wp_admin_bar;
        if ( !is_user_logged_in() ) { return; }
        if ( !is_admin_bar_showing() ) { return; }

    $wp_admin_bar->add_menu( array(
        'id' => 'lift_admin_bar_menu',
        'title' => __( '<span class="lifemx ab-icon ab-item"></span>LIFT Creations' ) ,
        'href'      => 'https://liftcreations.com/',
        'meta'   => array(
            'target'   => '_blank',
            'class'    => 'wpse--item',
            'tabindex' => PHP_INT_MAX,
        )
    ));

  $wp_admin_bar->add_menu( array(
    'parent'    => 'lift_admin_bar_menu',
    'title'     => '<span class="dashicons-before dashicons dashicons-groups"></span>About Us',
    'href'  => 'https://liftcreations.com/about/',
    'meta'  => array( 'target' => '_blank' )
   ));

    $wp_admin_bar->add_menu( array(
        'parent'    => 'lift_admin_bar_menu',
        'title'     => '<span class="dashicons-before dashicons dashicons-location"></span>Contact Us',
        'href'  => 'https://liftcreations.com/contact-us/',
        'meta'  => array( 'target' => '_blank' )
    ));
}
add_action( 'admin_bar_menu', 'admin_lift_menu' , 100);

// RENAME IMG 
add_action( 'carbon_fields_fields_registered', '___lift_auto_rename_img' );
function ___lift_auto_rename_img() {
    if(carbon_get_theme_option('___lift_auto_rename_img')) {
        add_filter( 'wp_handle_upload_prefilter', 'lift_custom_upload_filter' );
    }
}
function lift_custom_upload_filter( $file ) {
    if ( ! isset( $_REQUEST['post_id'] ) ) {
        return $file;
    }
    $id           = intval( $_REQUEST['post_id'] );
    $parent_post  = get_post( $id );
    $post_name    = sanitize_title( $parent_post->post_title );
    $file['name'] = $post_name . '-' . $file['name'];
    return $file;
}

// LOGIN LOGO 
add_action( 'login_enqueue_scripts', '___lift_login_logo' );
function ___lift_login_logo() {
    if(carbon_get_theme_option('___lift_login_logo')) {
        ?>
        <style type="text/css">
            #login h1 a, .login h1 a {
            background-image: url(<?php echo carbon_get_theme_option('___lift_login_logo'); ?>);
            height:<?php echo carbon_get_theme_option('___lift_login_logo_height')?carbon_get_theme_option('___lift_login_logo_height'): 'initial'; ?>;
            width:<?php echo carbon_get_theme_option('___lift_login_logo_width')?carbon_get_theme_option('___lift_login_logo_width'): 'initial'; ?>;
            margin-bottom:<?php echo carbon_get_theme_option('___lift_login_logo_margin')?carbon_get_theme_option('___lift_login_logo_margin'): 'initial'; ?>;
            background-size: contain;
            background-position: center center;
            background-repeat: no-repeat;
            }
        </style>
        <?php
    }
}

// UPDATE 

add_action( 'carbon_fields_fields_registered', '___lift_remove_core_email' );
function ___lift_remove_core_email() {
    if(carbon_get_theme_option('___lift_remove_core_email')) {
        add_filter('auto_core_update_send_email', '__return_false' );
    }
}
add_action( 'carbon_fields_fields_registered', '___lift_remove_plugins_email' );
function ___lift_remove_plugins_email() {
    if(carbon_get_theme_option('___lift_remove_plugins_email')) {
        add_filter('auto_plugin_update_send_email', '__return_false');
    }
}
add_action( 'carbon_fields_fields_registered', '___lift_remove_theme_email' );
function ___lift_remove_theme_email() {
    if(carbon_get_theme_option('___lift_remove_theme_email')) {
        add_filter('auto_theme_update_send_email', '__return_false');
    }
}
add_action( 'carbon_fields_fields_registered', '___lift_remove_core_update' );
function ___lift_remove_core_update() {
    if(carbon_get_theme_option('___lift_remove_core_update')) {
        add_filter('pre_option_update_core', '__return_null');
        add_filter('pre_site_transient_update_core','lift_remove_wp_core_updates');
    }
}
add_action( 'carbon_fields_fields_registered', '___lift_remove_plugins_update' );
function ___lift_remove_plugins_update() {
    if(carbon_get_theme_option('___lift_remove_plugins_update')) {
        add_filter('auto_update_plugin', '__return_false' );
        add_filter('plugins_auto_update_enabled', '__return_false' );
        add_filter('site_transient_update_plugins', '__return_null' );
        remove_action('load-update-core.php', 'wp_update_plugins');
        add_filter('pre_site_transient_update_plugins','lift_remove_wp_core_updates');
    }
}
add_action( 'carbon_fields_fields_registered', '___lift_remove_theme_update' );
function ___lift_remove_theme_update() {
    if(carbon_get_theme_option('___lift_remove_theme_update')) {
        add_filter('auto_update_theme', '__return_false' );
        add_filter('themes_auto_update_enabled', '__return_false' );
        add_filter('site_transient_update_themes', '__return_null' );
        remove_action('load-update-core.php', 'wp_update_themes');
        add_filter('pre_site_transient_update_themes','lift_remove_wp_core_updates');
    }
}
function lift_remove_wp_core_updates(){
    global $wp_version;
    return(object) array('last_checked' => time(),'version_checked' => $wp_version);
}