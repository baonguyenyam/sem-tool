<?php 
// https://github.com/reduxframework/redux-framework/blob/master/sample/sample-config.php
// https://devs.redux.io/guides/basics/getting-started.html
// https://github.com/reduxframework/redux-framework/blob/master/sample/barebones-config.php

require_once 'wp-content/plugins/redux-framework/ReduxCore/framework.php';
// require_once 'wp-content/plugins/redux-framework/sample/sample-config.php';

