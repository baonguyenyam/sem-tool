module.exports = {

    init: function () {
        // do something here
        //alert('example 2 is working...');
    }

};