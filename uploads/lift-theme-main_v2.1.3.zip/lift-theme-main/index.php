<?php

get_header();

get_template_part( 'templates/partials/example' );

get_footer();