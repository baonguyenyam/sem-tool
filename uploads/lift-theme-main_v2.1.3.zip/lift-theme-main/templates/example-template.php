<?php
/*
 * Template Name: Example Page Template
 * Template Post Type: post, page, whatever
 */

get_header();

?>
	<p>This is an example template</p>
<?php

get_footer();