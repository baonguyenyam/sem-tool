<?php wp_footer() ?>
</body>
</html>