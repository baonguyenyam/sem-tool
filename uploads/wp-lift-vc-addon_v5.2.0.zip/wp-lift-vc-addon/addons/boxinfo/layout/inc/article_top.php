<?php
$output .= '<article class="lift-ctn'.$textAlign.$css_animation.'">';