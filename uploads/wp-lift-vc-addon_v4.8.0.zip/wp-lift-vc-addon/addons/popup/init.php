<?php

if (!defined('ABSPATH')) {
	die('Silly human what are you doing here');
}


if (!class_exists('liftVC_Addons_Popup')) {

	class liftVC_Addons_Popup extends LIFT_Helpers
	{

		public $name = 'popup';
		public $pNicename = 'LIFT Popup';

		public function __construct()
		{

			add_action('wp_enqueue_scripts', array($this, 'load_scripts'));
			add_shortcode('lift-' . $this->name . '-shortcode', array($this, 'output'));

			// Map shortcode to Visual Composer
			if (function_exists('vc_lean_map')) {
				vc_lean_map('lift-' . $this->name . '-shortcode', array($this, 'functionLoader'));

			}
		}

		public function load_scripts()
		{
			wp_enqueue_script(
				'lift-' . $this->name,
				plugin_dir_url(__FILE__) . 'js/dist/main.prod.js',
				array('jquery'),
				LIFT_VERSION
			);
			wp_enqueue_style(
				'lift-' . $this->name,
				plugin_dir_url(__FILE__) . 'css/dist/main.min.css',
				array(),
				LIFT_VERSION
			);
		}

		public function functionLoader()
		{

			return array(
				'name'        => esc_html__($this->pNicename, 'js_composer'),
				'description' => esc_html__('Add new ' . $this->pNicename, 'js_composer'),
				'base'        => 'lift_vc_' . $this->name,
				'is_container' => true,
				'category' => __('LIFT Addons', 'js_composer'),
				'icon' => 'icon-lift-adminicon icon-lift-' . $this->name,
				'show_settings_on_create' => true,
				'params'      => array(
					array(
						'type' => 'textfield',
						'holder' => 'h4',
						'class' => 'lift-title',
						'heading' => __('Button text', 'js_composer'),
						'param_name' => 'popup_title',
						'value' => __('', 'js_composer'),
						'weight' => 0,
						'edit_field_class' => 'vc_col-sm-8 admin-lift-col pt-0',
						'group' => $this->pNicename,
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__( 'Button Tag', 'js_composer' ),
						'param_name' => 'popup_tag',
						'value' => 'p',
						'save_always' => true,
						'not_empty' => true,
						'value' => array(
							esc_html__( 'Default', 'js_composer' ) => 'p',
							esc_html__( 'p', 'js_composer' ) => 'p',
							esc_html__( 'div', 'js_composer' ) => 'div',
						),
						'edit_field_class' => 'vc_col-sm-4 admin-lift-col pt-0',
						'group' => $this->pNicename,
					),
					array(
						'type' => 'textfield',
						'class' => 'lift-title',
						'heading' => __('Heading', 'js_composer'),
						'param_name' => 'title',
						'value' => __('', 'js_composer'),
						'edit_field_class' => 'vc_col-sm-8 admin-lift-col',
						'group' => $this->pNicename,
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__( 'Heading Tag', 'js_composer' ),
						'param_name' => 'tag',
						'value' => 'h3',
						'admin_label' => false,
						'save_always' => true,
						'not_empty' => true,
						'value' => array(
							esc_html__( 'Default', 'js_composer' ) => 'h3',
							esc_html__( 'h2', 'js_composer' ) => 'h2',
							esc_html__( 'h3', 'js_composer' ) => 'h3',
							esc_html__( 'h4', 'js_composer' ) => 'h4',
							esc_html__( 'h5', 'js_composer' ) => 'h5',
							esc_html__( 'h6', 'js_composer' ) => 'h6',
							esc_html__( 'p', 'js_composer' ) => 'p',
							esc_html__( 'div', 'js_composer' ) => 'div',
						),
						'edit_field_class' => 'vc_col-sm-4 admin-lift-col',
						'group' => $this->pNicename,
					),
					array(
						'type' => 'textarea_html',
						'class' => 'lift-content',
						'heading' => __('Description', 'js_composer'),
						'param_name' => 'content',
						'admin_label' => false,
						'value' => __('<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>', 'js_composer'),
						'description' => __('To add link highlight text or url and click the chain to apply hyperlink', 'js_composer'),
						'group' => $this->pNicename,
					),
					array(
						'type' => 'checkbox',
						'heading' => esc_html__( 'Click to close', 'js_composer' ) . '?',
						'param_name' => 'click_to_close',
						'edit_field_class' => 'vc_col-sm-3 admin-lift-col pt-0',
						'group' => __('General', 'js_composer')
					),
					array(
						'type' => 'checkbox',
						'heading' => esc_html__( 'Disable animation', 'js_composer' ) . '?',
						'param_name' => 'add_animation',
						'edit_field_class' => 'vc_col-sm-3 admin-lift-col pt-0',
						'group' => __('General', 'js_composer')
					),
					array(
						'type' => 'checkbox',
						'heading' => esc_html__( 'Disable scrollable', 'js_composer' ),
						'param_name' => 'modal_touch',
						'edit_field_class' => 'vc_col-sm-3 admin-lift-col pt-0',
						'group' => __('General', 'js_composer')
					),
					array(
						'type' => 'checkbox',
						'heading' => esc_html__( 'Small Button', 'js_composer' ),
						'param_name' => 'small_button',
						'edit_field_class' => 'vc_col-sm-3 admin-lift-col pt-0',
						'group' => __('General', 'js_composer')
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__( 'Content Padding', 'js_composer' ),
						'param_name' => 'content_padding',
						'value' => '',
						'description' => esc_html__( 'Select box Content Padding', 'js_composer' ),
						'edit_field_class' => 'vc_col-sm-6 admin-lift-col',
						'group' => __('General', 'js_composer')
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__( 'Content Margin', 'js_composer' ),
						'param_name' => 'content_margin',
						'value' => '',
						'description' => esc_html__( 'Select box Content Margin', 'js_composer' ),
						'edit_field_class' => 'vc_col-sm-6 admin-lift-col',
						'group' => __('General', 'js_composer')
					),
					array(
						"type" => "lift_group_header",
						"class" => "",
						"heading" => esc_html__("Element", "js_composer" ),
						"param_name" => "group_header_1",
						"edit_field_class" => "",
						"value" => '',
						'group' => __('General', 'js_composer')
					),
					array(
						'type' => 'el_id',
						'heading' => esc_html__('Element ID', 'js_composer'),
						'param_name' => 'el_id',
						'group' => __('General', 'js_composer')
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Extra class name', 'js_composer'),
						'param_name' => 'el_class',
						'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS.', 'js_composer'),
						'group' => __('General', 'js_composer')
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('HTML Attribute', 'js_composer'),
						'param_name' => 'el_attribute',
						'description' => esc_html__('Enter html attr (Example: "data-bg").', 'js_composer'),
						'group' => __('General', 'js_composer')
					),

				),
			);
		}
		public function output($atts, $content = null)
		{

			$block_id = isset($atts['el_id']) ? ' id="'.$atts['el_id'].'"' : '';
			$attribute = isset($atts['el_attribute']) ? ' ' . $atts['el_attribute'] : '';
			$classname = isset($atts['el_class']) ? ' ' . $atts['el_class'] : '';
			$content_padding = isset($atts['content_padding']) ? $atts['content_padding'] : null;
			$content_margin = isset($atts['content_margin']) ? $atts['content_margin'] : null;
			$title = isset($atts['title']) ? $atts['title'] : null;
			$img_single = isset($atts['img_single']) ? $atts['img_single'] : null;
			$img_group = isset($atts['img_group']) ? $atts['img_group'] : null;
			$modal_touch = $atts['modal_touch'] ? true: false;
			$click_to_close = $atts['click_to_close'] ? true: false;
			$small_button = $atts['small_button'] ? true: false;
			$add_animation = $atts['add_animation'] ? true: false;
			$tag = isset($atts["tag"]) ? $atts["tag"] : 'h3';
			$popup_tag = isset($atts["popup_tag"]) ? $atts["popup_tag"] : 'h3';
			$popup_title = isset($atts["popup_title"]) ? $atts["popup_title"] : 'Popup';

			// Admin
			$settings = shortcode_atts(array(
				'el_attribute' => '',
				'el_id' => '',
				'el_class' => '',
			), $atts);
			extract($settings);
			
			// CSSBUILD 
			$randomNumClass = $this->generateRandomString(10);
			$cssname = '.fancybox-container .fancybox-stage #modal'.$randomNumClass;
			$css_build = '';
			$css_build .= $content_padding ? ''. $cssname.'{padding:'.$content_padding.'!important;}' : null;
			$css_build .= $content_margin ? ''. $cssname.'{margin:'.$content_margin.'!important;}' : null;

			$modal_build = '';
			$modal_build .= $click_to_close ? ' data-modal="true"' : '';
			$modal_build .= $add_animation ? ' data-animation-duration="0"' : '';
			$modal_build .= $modal_touch ? ' data-touch="false"' : '';
			$modal_build .= $small_button ? ' data-options=\'{"smallBtn" : false}\'' : '';
			
			// FrontEnd
			$output = $css_build ? '<style>' .$css_build. '</style>' : '';
			$output .= '<section'. $block_id .' class="lift-elements lift-' . $this->name. $classname.'"' . str_replace('``', '', $attribute) . '>';
			$output .= $popup_title ? $this->applyHeadingCustomPost($popup_title,$popup_tag,'javascript:;','data-fancybox data-src="#modal'.$randomNumClass.'"'.$modal_build.'') : null;

			$output .= '<div style="display: none;" id="modal'.$randomNumClass.'">';
			$output .=  $title ? $this->applyHeadingCustomPost($title,$tag) : null;
			$output .= $content ? '<div class="lift-popup-content"><p>' . do_shortcode($content) . '</p></div>' : null;
			$output .= $click_to_close ? '<div class="lift-click-to-close"><button data-fancybox-close class="fancybox-button fancybox-button--close" title="Close"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 10.6L6.6 5.2 5.2 6.6l5.4 5.4-5.4 5.4 1.4 1.4 5.4-5.4 5.4 5.4 1.4-1.4-5.4-5.4 5.4-5.4-1.4-1.4-5.4 5.4z"></path></svg></button></div>' : null;
			$output .= '</div>';
			$output .= '</section>';
			$output .= '<!-- .lift-' . $this->name . ' -->';

			return apply_filters(
				'lift_' . $this->name . '_output',
				$output,
				$content,
				$settings
			);
		}

	}
}
new liftVC_Addons_Popup;
