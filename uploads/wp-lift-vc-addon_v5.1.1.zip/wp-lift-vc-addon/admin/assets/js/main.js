window.addEventListener('load', function () {
    if (document.getElementById("nectar-metabox-fullscreen-rows")) {
        var liftAdminCss = '.wpb-content-layouts-container .wpb-content-layouts li:hover[data-element*=lift-] .icon-lift-adminicon { filter: invert(1) brightness(100); opacity: 1; } .wpb-content-layouts-container .wpb-content-layouts li:hover[data-element*=lift-]:after { filter: invert(1) brightness(100); }';
        var liftAdminhead = document.head || document.getElementsByTagName('head')[0];
        var liftAdminstyle = document.createElement('style');
        liftAdminhead.appendChild(liftAdminstyle);
        if (liftAdminstyle.styleSheet) {
            liftAdminstyle.styleSheet.cssText = liftAdminCss;
        } else {
            liftAdminstyle.appendChild(document.createTextNode(liftAdminCss));
        }
    }
})