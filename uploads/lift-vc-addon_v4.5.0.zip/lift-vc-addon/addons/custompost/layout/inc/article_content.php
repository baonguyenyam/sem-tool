<?php 
$output .= get_the_excerpt($value->ID) ? '<div class="lift-content"><p>' . wp_trim_words(get_the_excerpt($value->ID),$number_words,str_replace('}', ']',str_replace('{', '[',str_replace('`', '', $trim_words)))) . '</p></div>' : null;
